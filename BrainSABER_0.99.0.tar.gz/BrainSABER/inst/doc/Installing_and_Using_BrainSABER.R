## ----setup, include=FALSE------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)

## ---- eval=FALSE---------------------------------------------------------
#  # for R version >= 3.5
#  if (!requireNamespace("BiocManager", quietly = TRUE))
#      install.packages("BiocManager")
#  BiocManager::install("AIBSARNA")
#  BiocManager::install("BrainSABER")

## ----loadpkg, message=FALSE, warning=FALSE, results='hide'---------------
library(BrainSABER)

## ----getSampleData, message=FALSE, warning=FALSE, results='hide'---------
# load AIBSARNA data package 
library(AIBSARNA)
data("AIBSARNA")

# Obtain the sample indexes to use for subsetting (not random)
sample_idx <- 1:50 * 10 - 1
# Set the RNG seed for repeatable results
set.seed(8)
# Get the total number of genes available
totalGenes <- nrow(AIBSARNA)
# Sample the indices of 200 random genes
gene_idx <- sample.int(totalGenes, 200)

# Subset AIBSARNA
toy_exprs <- exprs(AIBSARNA)[gene_idx, sample_idx]
toy_fd <- fData(AIBSARNA)[gene_idx, ]
toy_pd <- pData(AIBSARNA)[sample_idx, ]

# Convert feature and pheno data to AnnotatedDataFrame required by ExpressionSet

toy_featureData <- AnnotatedDataFrame(data = toy_fd)
toy_phenoData <- AnnotatedDataFrame(data = toy_pd)

# Create toy ExpressionSet
toySet <- ExpressionSet(assayData = toy_exprs,
                        featureData = toy_featureData,
                        phenoData = toy_phenoData)


## ----saveCSV-------------------------------------------------------------
write.csv(toy_exprs, file = "toy_expression_matrix.csv")
write.csv(as.data.frame(toy_fd), file = "toy_gene_identification_data.csv")
write.csv(as.data.frame(toy_pd), file = "toy_sample_information_data.csv")

## ----runShinyBrainsABER, eval=FALSE--------------------------------------
#  runShinyBrainSABER()

## ----sessionInfo---------------------------------------------------------
sessionInfo()

