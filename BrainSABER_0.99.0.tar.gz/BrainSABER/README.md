#BrainSABER



This package contains tools to compare gene expression data to data from The Allen Institute for Brain Science BrainSpan Atlas, found separately in the AIBSARNA package.  For more information, please see the vignette, Installing_and_Using_BrainSABER.html

To install using devtools, enter the following command in R: 
install_bitbucket("BiCBioEng/brainsaber", auth_user = <your Bitbucket username>, password = <your Bitbucket password>)