#AIBSARNA

This package contains The Allen Institute for Brain Science BrainSpan Atlas of the Developing Human Brain Developmental Transcriptome RNA-Seq Gencode v10 summarized to genes dataset implemented as a Bioconductor Biobase ExpressionSet.  In addition, this ExpressionSet also contains relevant RefSeq mRNA IDs.

To install using devtools, enter the following command in R:
install_bitbucket("BiCBioEng/aibsarna", auth_user = <your Bitbucket username>, password = <your Bitbucket password>)