#' Allen Institute BrainSpan Atlas RNA
#'
#' A Biobase ExpressionSet containing the Allen Institute for Brain Science
#' BrainSpan Atlas of the Developing Human Brain Developmental Transcriptome
#' RNA-Seq Gencode v10 summarized to genes.
#'
#'Citation:
#'BrainSpan: Atlas of the Developing Human Brain [Internet]. Funded by ARRA
#'  Awards 1RC2MH089921-01, 1RC2MH090047-01, and 1RC2MH089929-01. © 2011.
#'  Available from:
#'  @source \url{http://developinghumanbrain.org.}
#'
"AIBSARNA"
